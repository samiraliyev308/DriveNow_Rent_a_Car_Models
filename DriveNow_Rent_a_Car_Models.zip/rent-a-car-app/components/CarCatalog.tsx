import React from 'react';
import { FlatList, ListRenderItem, StyleProp, ViewStyle } from 'react-native';
import { Car } from '../data/cars';
import CarCard from './CarCard';
import { useTheme } from '../context/AppContext';

type CarCatalogProps = {
  cars: Car[];
  ListHeaderComponent?: React.ComponentType<any> | React.ReactElement | null;
  ListEmptyComponent?: React.ComponentType<any> | React.ReactElement | null;
  contentContainerStyle?: StyleProp<ViewStyle>;
  onRefresh?: () => void;
  refreshing?: boolean;
};

export default function CarCatalog({
  cars,
  ListHeaderComponent,
  ListEmptyComponent,
  contentContainerStyle,
  onRefresh,
  refreshing = false,
}: CarCatalogProps) {
  const {colors} = useTheme();
  const renderCar: ListRenderItem<Car> = ({ item }) => <CarCard car={item} />;

  return (
    <FlatList
      data={cars}
      renderItem={renderCar}
      keyExtractor={(item) => item.id}
      ListHeaderComponent={ListHeaderComponent}
      ListEmptyComponent={ListEmptyComponent}
      contentContainerStyle={contentContainerStyle}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      onRefresh={onRefresh}
      refreshing={refreshing}
      style={{ flex: 1, backgroundColor: colors.bg }}
    />
  );
}
