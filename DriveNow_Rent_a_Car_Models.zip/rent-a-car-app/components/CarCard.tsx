import React from 'react';
import {View,Text,Image,Pressable,StyleSheet} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import {router} from 'expo-router';
import {Car} from '../data/cars';
import {useTheme} from '../context/AppContext';
import {useApp} from '../context/AppContext';
export default function CarCard({car}: {car:Car}) {
 const {colors:C}=useTheme();
 const s=makeStyles(C);
 const {favorites,toggleFavorite}=useApp(); const liked=favorites.includes(car.id);
 return <Pressable style={s.card} onPress={()=>router.push(`/car/${car.id}`)}>
  <View style={s.imageWrap}><Image source={{uri:car.image}} style={s.image}/>{car.tag&&<Text style={s.tag}>{car.tag}</Text>}
   <Pressable style={s.heart} onPress={(e:any)=>{e.stopPropagation?.();toggleFavorite(car.id)}}><Ionicons name={liked?'heart':'heart-outline'} size={19} color={liked?C.accent:C.text}/></Pressable>
  </View>
  <View style={s.info}><View style={{flex:1}}><Text style={s.brand}>{car.brand}</Text><Text style={s.name}>{car.name}</Text><Text style={s.meta}>{car.transmission} · {car.fuel} · {car.seats} seats</Text></View>
   <View style={s.priceBox}><Text style={s.price}>${car.price}</Text><Text style={s.day}>/ day</Text></View></View>
  <View style={s.rating}><Ionicons name="star" color={C.accent} size={13}/><Text style={s.ratingText}>{car.rating}</Text><Text style={s.ratingMuted}> · Available now</Text></View>
 </Pressable>
}
const makeStyles=(C:any)=>StyleSheet.create({card:{backgroundColor:C.panel,borderRadius:19,padding:10,marginBottom:15,borderWidth:1,borderColor:C.line},imageWrap:{height:155,borderRadius:13,overflow:'hidden',backgroundColor:C.panel2},image:{width:'100%',height:'100%',resizeMode:'cover'},tag:{position:'absolute',top:12,left:12,backgroundColor:C.accent,color:'#111',fontSize:9,fontWeight:'900',paddingHorizontal:9,paddingVertical:6,borderRadius:6,overflow:'hidden'},heart:{position:'absolute',right:11,top:11,width:34,height:34,borderRadius:17,backgroundColor:'rgba(10,10,10,0.65)',alignItems:'center',justifyContent:'center'},info:{flexDirection:'row',alignItems:'center',paddingHorizontal:5,paddingTop:12},brand:{color:C.muted,fontSize:11},name:{color:C.text,fontSize:19,fontWeight:'900',marginTop:2},meta:{color:C.muted,fontSize:10,marginTop:5},priceBox:{alignItems:'flex-end'},price:{color:C.accent,fontSize:20,fontWeight:'900'},day:{color:C.muted,fontSize:10},rating:{flexDirection:'row',alignItems:'center',paddingHorizontal:5,marginTop:10},ratingText:{color:C.text,fontWeight:'700',fontSize:11,marginLeft:5},ratingMuted:{color:C.muted,fontSize:10}});
