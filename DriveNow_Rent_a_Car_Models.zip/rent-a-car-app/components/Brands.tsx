import React from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useTheme } from '../context/AppContext';

type Props = { brands: string[]; selectedBrand: string; onSelect: (brand: string) => void };

export default function Brands({ brands, selectedBrand, onSelect }: Props) {
  const { colors: C } = useTheme();
  return (
    <View style={styles.wrapper}>
      <Text style={[styles.heading, { color: C.text }]}>BRANDS</Text>
      <FlatList horizontal data={brands} keyExtractor={(item) => item}
        showsHorizontalScrollIndicator={false} contentContainerStyle={styles.list}
        renderItem={({ item }) => {
          const active = item === selectedBrand;
          return <Pressable onPress={() => onSelect(item)} style={[styles.chip, { backgroundColor: active ? C.accent : C.panel, borderColor: active ? C.accent : C.line }]}>
            <Text style={[styles.label, { color: active ? '#111111' : C.text }]}>{item}</Text>
          </Pressable>;
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: { marginBottom: 22 }, heading: { fontSize: 11, fontWeight: '900', letterSpacing: 1.7, marginBottom: 12 },
  list: { gap: 9, paddingRight: 20 }, chip: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 11 },
  label: { fontSize: 12, fontWeight: '800' },
});
