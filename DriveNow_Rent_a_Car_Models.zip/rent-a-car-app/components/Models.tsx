import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { Car } from '../data/cars';
import { useTheme } from '../context/AppContext';
import CarCatalog from './CarCatalog';

type Props = { cars: Car[]; header?: React.ReactElement | null };

export default function Models({ cars, header = null }: Props) {
  const { colors: C } = useTheme();
  const empty = <Text style={[styles.empty, { color: C.muted }]}>No models found for this brand.</Text>;
  return <CarCatalog cars={cars} ListHeaderComponent={header} ListEmptyComponent={empty} contentContainerStyle={styles.content} />;
}

const styles = StyleSheet.create({ content: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 30, flexGrow: 1 }, empty: { textAlign: 'center', marginTop: 48, fontSize: 13 } });
