# DriveNow — Car Rental App

Готовый учебный проект React Native + Expo Router.

## Запуск
1. Установи Node.js LTS.
2. Распакуй архив и открой папку проекта в VS Code.
3. В терминале выполни:
   ```bash
   npm install
   npx expo start
   ```
4. Открой Expo Go на телефоне и отсканируй QR-код.

Для браузера: `npm run web`.

## Что реализовано
- Launch / welcome screen.
- Login и Register с локальной демонстрационной авторизацией.
- Главная страница с поиском, категориями и карточками авто.
- Tabs: Home, Explore, Bookings, Profile.
- Поиск и фильтрация автомобилей.
- Избранное, просмотр деталей и добавление машины в бронирования.
- Профиль с выходом из аккаунта.

Авторизация и бронирования демонстрационные: сервер и реальная оплата не подключены.


## Light and Dark themes

The app includes a shared `useTheme()` hook. Open **Profile → Preferences → Appearance** to switch between Light and Dark themes. The selected theme updates the Launch, Authentication, Home, Explore, Bookings, Profile, car details, catalog cards, and tab navigation screens while the app is running. Theme state is currently kept in app memory and resets to Dark after a full app restart.
