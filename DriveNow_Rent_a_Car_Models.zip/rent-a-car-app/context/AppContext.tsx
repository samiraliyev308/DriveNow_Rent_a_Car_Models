import React, {createContext, useContext, useState} from 'react';
import {Car} from '../data/cars';
import {palettes, ThemeName} from '../constants/theme';
type Booking = {car: Car; date: string};
type ContextType = {theme:ThemeName; colors:typeof palettes.dark; toggleTheme:()=>void; user:string|null; login:(name:string)=>void; logout:()=>void; favorites:string[]; toggleFavorite:(id:string)=>void; bookings:Booking[]; addBooking:(car:Car)=>void};
const AppContext = createContext<ContextType | null>(null);
export function AppProvider({children}:{children:React.ReactNode}) {
 const [user,setUser]=useState<string|null>(null);
 const [theme,setTheme]=useState<ThemeName>('dark');
 const colors=palettes[theme];
 const toggleTheme=()=>setTheme(current=>current==='dark'?'light':'dark');
 const [favorites,setFavorites]=useState<string[]>([]);
 const [bookings,setBookings]=useState<Booking[]>([]);
 const login=(name:string)=>setUser(name.trim()||'Alex Morgan');
 const logout=()=>setUser(null);
 const toggleFavorite=(id:string)=>setFavorites(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id]);
 const addBooking=(car:Car)=>setBookings(old=>old.some(x=>x.car.id===car.id)?old:[...old,{car,date:'Today · Flexible pickup'}]);
 return <AppContext.Provider value={{theme,colors,toggleTheme,user,login,logout,favorites,toggleFavorite,bookings,addBooking}}>{children}</AppContext.Provider>;
}
export function useApp(){const value=useContext(AppContext);if(!value)throw new Error('AppProvider is missing');return value;}

export function useTheme(){const value=useContext(AppContext);if(!value)throw new Error('AppProvider is missing');return {theme:value.theme,colors:value.colors,toggleTheme:value.toggleTheme};}
