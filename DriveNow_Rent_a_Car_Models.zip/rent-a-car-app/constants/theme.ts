export const palettes = {
  dark: {
    bg: '#101114', panel: '#191B20', panel2: '#22252B', text: '#F7F7F5',
    muted: '#92969F', accent: '#FFC928', line: '#2B2E35', white: '#FFFFFF',
    green: '#7DD3A7', red: '#FF7777', input: '#191B20', tab: '#17191E',
  },
  light: {
    bg: '#F5F6F8', panel: '#FFFFFF', panel2: '#ECEFF3', text: '#17191E',
    muted: '#737985', accent: '#E5A900', line: '#E0E3E8', white: '#FFFFFF',
    green: '#218653', red: '#D94848', input: '#FFFFFF', tab: '#FFFFFF',
  },
};
export type ThemeName = keyof typeof palettes;
// Default palette retained for static decorative styles; screens use useTheme() for live colors.
export const C = palettes.dark;
