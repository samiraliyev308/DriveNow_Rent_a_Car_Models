import React, { useMemo, useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { CARS } from '../../data/cars';
import {useTheme} from '../../context/AppContext';
import CarCatalog from '../../components/CarCatalog';

const categories = ['All', 'Electric', 'Luxury', 'Sports', 'SUV', 'Sedan'];

export default function Explore() {
 const {colors:C}=useTheme();
 const s=makeStyles(C);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');
  const filtered = useMemo(
    () => CARS.filter((car) =>
      (category === 'All' || car.category === category) &&
      `${car.brand} ${car.name} ${car.category}`.toLowerCase().includes(query.toLowerCase())
    ),
    [query, category]
  );

  const header = (
    <>
      <Text style={s.kicker}>THE COLLECTION</Text>
      <Text style={s.title}>Explore cars</Text>
      <Text style={s.sub}>Find the car that fits your next adventure.</Text>
      <View style={s.search}>
        <Ionicons name="search" size={18} color={C.muted} />
        <TextInput value={query} onChangeText={setQuery} placeholder="Search cars..." placeholderTextColor={C.muted} style={s.input} />
        {query.length > 0 && <Pressable onPress={() => setQuery('')}><Ionicons name="close-circle" size={18} color={C.muted} /></Pressable>}
      </View>
      <View style={s.chips}>
        {categories.map((item) => (
          <Pressable key={item} onPress={() => setCategory(item)} style={[s.chip, category === item && s.chipActive]}>
            <Text style={[s.chipText, category === item && s.chipTextActive]}>{item}</Text>
          </Pressable>
        ))}
      </View>
      <Text style={s.count}>{filtered.length} VEHICLES AVAILABLE</Text>
    </>
  );

  return (
    <CarCatalog
      cars={filtered}
      ListHeaderComponent={header}
      ListEmptyComponent={<Text style={s.empty}>No cars found. Try another search.</Text>}
      contentContainerStyle={s.content}
    />
  );
}

const makeStyles=(C:any)=>StyleSheet.create({
  content: { padding: 20, paddingTop: 60, paddingBottom: 25, flexGrow: 1 },
  kicker: { color: C.accent, fontSize: 9, fontWeight: '900', letterSpacing: 2 },
  title: { color: C.text, fontSize: 32, fontWeight: '900', marginTop: 7 },
  sub: { color: C.muted, fontSize: 12, marginTop: 7 },
  search: { backgroundColor: C.panel, borderColor: C.line, borderWidth: 1, borderRadius: 13, marginTop: 22, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 10 },
  input: { height: 50, color: C.text, flex: 1, fontSize: 13 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 17, gap: 8 },
  chip: { borderRadius: 10, borderWidth: 1, borderColor: C.line, paddingHorizontal: 15, paddingVertical: 10, backgroundColor: C.panel },
  chipActive: { backgroundColor: C.accent, borderColor: C.accent },
  chipText: { color: C.muted, fontSize: 11, fontWeight: '700' },
  chipTextActive: { color: '#111' },
  count: { color: C.muted, fontSize: 9, fontWeight: '900', letterSpacing: 1.5, marginTop: 22, marginBottom: 13 },
  empty: { color: C.muted, textAlign: 'center', marginTop: 50 },
});
