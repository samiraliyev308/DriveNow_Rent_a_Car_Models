import React, { useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Brands from '../../components/Brands';
import Models from '../../components/Models';
import { CARS } from '../../data/cars';
import { useTheme } from '../../context/AppContext';

export default function ModelsScreen() {
  const { colors: C } = useTheme();
  const [selectedBrand, setSelectedBrand] = useState('All');
  const brands = useMemo(() => ['All', ...Array.from(new Set(CARS.map((car) => car.brand)))], []);
  const filteredCars = useMemo(() => selectedBrand === 'All' ? CARS : CARS.filter((car) => car.brand === selectedBrand), [selectedBrand]);
  const header = <View>
    <Text style={[styles.kicker, { color: C.accent }]}>FIND YOUR MATCH</Text>
    <Text style={[styles.title, { color: C.text }]}>Car models</Text>
    <Text style={[styles.subtitle, { color: C.muted }]}>Choose a brand and explore its available models.</Text>
    <Brands brands={brands} selectedBrand={selectedBrand} onSelect={setSelectedBrand} />
    <Text style={[styles.results, { color: C.muted }]}>{filteredCars.length} MODELS AVAILABLE</Text>
  </View>;
  return <Models cars={filteredCars} header={header} />;
}

const styles = StyleSheet.create({
  kicker: { fontSize: 9, fontWeight: '900', letterSpacing: 2 }, title: { fontSize: 32, fontWeight: '900', marginTop: 7 },
  subtitle: { fontSize: 12, marginTop: 7, marginBottom: 24 }, results: { fontSize: 9, fontWeight: '900', letterSpacing: 1.5, marginBottom: 14 },
});
