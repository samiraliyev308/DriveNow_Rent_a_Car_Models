import React from 'react';
import { View, Text, Pressable, StyleSheet, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { CARS } from '../../data/cars';
import {useTheme} from '../../context/AppContext';
import { useApp } from '../../context/AppContext';
import CarCatalog from '../../components/CarCatalog';

export default function Home() {
 const {colors:C}=useTheme();
 const s=makeStyles(C);
  const { user } = useApp();

  const header = (
    <>
      <View style={s.header}>
        <View>
          <Text style={s.greet}>GOOD MORNING</Text>
          <Text style={s.user}>{user || 'Guest'} <Text style={{ color: C.accent }}>✦</Text></Text>
        </View>
        <View style={s.avatar}><Ionicons name="person" color={C.accent} size={20} /></View>
      </View>
      <View style={s.hero}>
        <Text style={s.heroEyebrow}>DRIVE YOUR WAY</Text>
        <Text style={s.heroTitle}>Find your{'\n'}perfect ride.</Text>
        <Text style={s.heroSub}>Premium cars. Unforgettable journeys.</Text>
        <Pressable style={s.heroBtn} onPress={() => router.push('/(tabs)/explore')}>
          <Text style={s.heroBtnText}>Explore cars</Text>
          <Ionicons name="arrow-forward" color="#111" size={17} />
        </Pressable>
        <Image source={{ uri: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=900' }} style={s.heroImage} />
      </View>
      <Pressable style={s.search} onPress={() => router.push('/(tabs)/explore')}>
        <Ionicons name="search" color={C.muted} size={19} />
        <Text style={s.searchText}>Search brand, model or type</Text>
        <Ionicons name="options-outline" color={C.accent} size={20} />
      </Pressable>
      <View style={s.sectionHead}>
        <Text style={s.sectionTitle}>Popular cars</Text>
        <Pressable onPress={() => router.push('/(tabs)/explore')}><Text style={s.see}>See all  ↗</Text></Pressable>
      </View>
    </>
  );

  return <CarCatalog cars={CARS.slice(0, 3)} ListHeaderComponent={header} contentContainerStyle={s.content} />;
}

const makeStyles=(C:any)=>StyleSheet.create({
  content: { padding: 20, paddingTop: 58, paddingBottom: 25 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 },
  greet: { color: C.muted, fontSize: 9, fontWeight: '800', letterSpacing: 2 },
  user: { color: C.text, fontSize: 22, fontWeight: '900', marginTop: 5 },
  avatar: { width: 43, height: 43, borderRadius: 15, backgroundColor: C.panel, borderWidth: 1, borderColor: C.line, alignItems: 'center', justifyContent: 'center' },
  hero: { backgroundColor: C.panel2, borderRadius: 22, padding: 20, minHeight: 215, overflow: 'hidden', marginBottom: 17 },
  heroEyebrow: { color: C.accent, fontSize: 9, fontWeight: '900', letterSpacing: 2 },
  heroTitle: { color: C.text, fontSize: 33, fontWeight: '900', lineHeight: 35, marginTop: 9 },
  heroSub: { color: C.muted, fontSize: 11, marginTop: 8 },
  heroBtn: { backgroundColor: C.accent, borderRadius: 10, alignSelf: 'flex-start', paddingHorizontal: 13, paddingVertical: 10, marginTop: 15, flexDirection: 'row', gap: 9, alignItems: 'center', zIndex: 2 },
  heroBtnText: { color: '#111', fontWeight: '900', fontSize: 11 },
  heroImage: { position: 'absolute', width: 180, height: 120, right: -24, bottom: -1, resizeMode: 'contain', opacity: 0.9 },
  search: { backgroundColor: C.panel, borderColor: C.line, borderWidth: 1, borderRadius: 14, padding: 15, flexDirection: 'row', alignItems: 'center', gap: 11 },
  searchText: { color: C.muted, fontSize: 12, flex: 1 },
  sectionHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 25, marginBottom: 15 },
  sectionTitle: { color: C.text, fontSize: 20, fontWeight: '900' },
  see: { color: C.accent, fontSize: 11, fontWeight: '800' },
});
