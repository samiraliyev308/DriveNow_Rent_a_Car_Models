import React from 'react';
import {Tabs} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {useTheme} from '../../context/AppContext';
export default function TabLayout(){
 const {colors:C}=useTheme();
 return <Tabs screenOptions={{headerShown:false,tabBarStyle:{backgroundColor:C.tab,borderTopColor:C.line,height:82,paddingTop:9,paddingBottom:20},tabBarActiveTintColor:C.accent,tabBarInactiveTintColor:C.muted,tabBarLabelStyle:{fontSize:10,fontWeight:'700',marginTop:2}}}>
 <Tabs.Screen name="index" options={{title:'Home',tabBarIcon:({color,size})=><Ionicons name="home" color={color} size={size}/>}}/>
 <Tabs.Screen name="explore" options={{title:'Explore',tabBarIcon:({color,size})=><Ionicons name="search" color={color} size={size}/>}}/>
 <Tabs.Screen name="models" options={{title:'Models',tabBarIcon:({color,size})=><Ionicons name="car-sport" color={color} size={size}/>}}/>
 <Tabs.Screen name="bookings" options={{title:'Bookings',tabBarIcon:({color,size})=><Ionicons name="calendar" color={color} size={size}/>}}/>
 <Tabs.Screen name="profile" options={{title:'Profile',tabBarIcon:({color,size})=><Ionicons name="person" color={color} size={size}/>}}/>
 </Tabs>;
}
