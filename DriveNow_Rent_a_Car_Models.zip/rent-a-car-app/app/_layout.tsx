import React from 'react';
import {Stack} from 'expo-router';
import {StatusBar} from 'expo-status-bar';
import {AppProvider, useTheme} from '../context/AppContext';
function Navigator(){
 const {colors,theme}=useTheme();
 return <><StatusBar style={theme==='dark'?'light':'dark'}/><Stack screenOptions={{headerShown:false,contentStyle:{backgroundColor:colors.bg}}}><Stack.Screen name="index"/><Stack.Screen name="auth"/><Stack.Screen name="(tabs)"/><Stack.Screen name="car/[id]" options={{presentation:'card'}}/></Stack></>;
}
export default function RootLayout(){return <AppProvider><Navigator/></AppProvider>}
